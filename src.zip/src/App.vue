<template>
  <div>
    <RouterLink to="/">Home</RouterLink> |
    <RouterLink to="/products">Products</RouterLink>
    <RouterView />
  </div>
</template>

<script>
export default {
  setup() {

  }
}
</script>

<style>

</style>